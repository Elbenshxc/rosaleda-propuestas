(() => {
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const entrance = document.querySelector('.entrance');
  const logo = document.querySelector('.entrance-logo');
  const background = [...document.querySelectorAll('header, main, footer, .skip')];
  let introAnimations = [];
  let introTimer;
  function finishIntro() {
    clearTimeout(introTimer);
    introAnimations.forEach(a => a.cancel());
    introAnimations = [];
    entrance.classList.remove('is-active');
    entrance.setAttribute('aria-hidden', 'true');
    entrance.inert = true;
    background.forEach(el => el.inert = false);
    document.body.style.overflow = '';
  }
  function playIntro() {
    finishIntro();
    if (reduced) return;
    window.scrollTo({top:0,behavior:'instant'});
    entrance.inert = false;
    entrance.classList.add('is-active');
    entrance.setAttribute('aria-hidden', 'false');
    background.forEach(el => el.inert = true);
    document.body.style.overflow = 'hidden';
    introAnimations.push(logo.animate([
      {transform:'translateY(-55px)'},
      {transform:'translateY(0)'}
    ], {duration:1100,delay:0,easing:'cubic-bezier(.22,1,.36,1)',fill:'both'}));
    const slide = entrance.animate([
      {transform:'translateY(0)'},
      {transform:'translateY(101%)'}
    ],{duration:1400,delay:1600,easing:'cubic-bezier(.76,0,.24,1)',fill:'forwards'});
    introAnimations.push(slide);
    slide.finished.then(finishIntro).catch(()=>{});
    introTimer = setTimeout(finishIntro, 4500);
  }
  document.querySelectorAll('[data-replay]').forEach(b=>b.addEventListener('click',playIntro));
  let transitionPending = false;
  try { transitionPending = sessionStorage.getItem('rosaleda-transition') === '1'; sessionStorage.removeItem('rosaleda-transition'); } catch {}
  if (!transitionPending) playIntro(); else finishIntro();

  const panel = document.querySelector('.menu-panel');
  const trigger = document.querySelector('.menu-trigger');
  const close = document.querySelector('.menu-close');
  let previousFocus;
  function setMenu(open) {
    if (open) previousFocus = document.activeElement;
    panel.classList.toggle('is-open',open);
    panel.inert = !open;
    panel.setAttribute('aria-hidden', String(!open));
    trigger.setAttribute('aria-expanded',String(open));
    document.body.classList.toggle('menu-open',open);
    background.forEach(el => el.inert = open);
    if (open) close.focus({preventScroll:true});
    else previousFocus?.focus({preventScroll:true});
  }
  panel.inert = true;
  trigger.addEventListener('click',()=>setMenu(true));
  close.addEventListener('click',()=>setMenu(false));
  document.addEventListener('keydown',e=>{
    if (!panel.classList.contains('is-open')) return;
    if (e.key==='Escape') setMenu(false);
    if (e.key==='Tab') {
      const all = [...panel.querySelectorAll('a[href],button')];
      const first=all[0], last=all[all.length-1];
      if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}
      else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}
    }
  });

  const curtain = document.querySelector('.transition-curtain');
  if (transitionPending && !reduced) curtain.animate([
    {transform:'translateY(0)'},{transform:'translateY(102%)'}
  ],{duration:1250,easing:'cubic-bezier(.76,0,.24,1)',fill:'forwards'});
  let leaving=false;
  document.querySelectorAll('a[data-route]').forEach(a=>a.addEventListener('click',e=>{
    if(e.metaKey||e.ctrlKey||e.shiftKey||e.altKey||e.button!==0)return;
    const url = new URL(a.href);
    if(url.pathname===location.pathname){e.preventDefault();setMenu(false);window.scrollTo({top:0,behavior:reduced?'instant':'smooth'});return}
    if(reduced)return;
    e.preventDefault();if(leaving)return;leaving=true;
    curtain.style.zIndex='95';
    curtain.animate([{transform:'translateY(-102%)'},{transform:'translateY(0)'}],{
      duration:1000,easing:'cubic-bezier(.76,0,.24,1)',fill:'forwards'
    }).finished.then(()=>{try{sessionStorage.setItem('rosaleda-transition','1')}catch{} location.href=a.href;});
  }));
  window.addEventListener('pageshow', e=>{if(e.persisted){leaving=false;curtain.getAnimations().forEach(a=>a.cancel());curtain.style.transform='translateY(-102%)';finishIntro()}});
})();
